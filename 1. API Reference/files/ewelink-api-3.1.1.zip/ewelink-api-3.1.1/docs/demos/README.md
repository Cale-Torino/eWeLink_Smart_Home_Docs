# Demos

### node script
* [Read](node.md) how to use this library on a nodejs script.


### serverless
* [Read](serverless.md) how to integrate on your serverles environment, like a lambda function.