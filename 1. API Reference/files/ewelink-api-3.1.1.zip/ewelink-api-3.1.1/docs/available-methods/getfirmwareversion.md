# getFirmwareVersion

Return firmware version for specified device.


### Usage
```
  const firmware = await connection.getFirmwareVersion('<your device id>');
  console.log(firmware);
```

<sup>* _Remember to instantiate class before use_</sup>