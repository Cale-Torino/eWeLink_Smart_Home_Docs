# getDevices

Returns a list of devices associated to logged account.


### Usage
```
  /* get all devices */
  const devices = await connection.getDevices();
  console.log(devices);
```

<sup>* _Remember to instantiate class before use_</sup>