# getDevice

Return information for specified device.


### Usage
```
  /* get specific device information */
  const device = await connection.getDevice('<your device id>');
  console.log(device);
```

<sup>* _Remember to instantiate class before use_</sup>