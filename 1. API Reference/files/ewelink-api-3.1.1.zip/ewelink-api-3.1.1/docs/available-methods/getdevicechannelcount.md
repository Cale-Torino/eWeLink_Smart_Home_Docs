# getDeviceChannelCount

Return total channels for specified device.


### Usage
```
  const channels = await connection.getDeviceChannelCount('<your device id>');
  console.log(channels);
```

<sup>* _Remember to instantiate class before use_</sup>