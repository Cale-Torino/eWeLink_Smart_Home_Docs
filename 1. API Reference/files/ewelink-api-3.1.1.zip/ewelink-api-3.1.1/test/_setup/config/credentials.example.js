module.exports = {
  // eWeLink credentials
  email: '<your ewelink email>',
  password: '<your ewelink password>',
  region: '<your ewelink region>',

  // zeroconf
  localIp: '<your network ip addreess>',
  localIpInvalid: '<an invalid network address>',

  // devices
  singleChannelDeviceId: '<your device id>',
  deviceIdWithPower: '<your device id>',
  deviceIdWithoutPower: '<your device id>',
  deviceIdWithTempAndHum: '<your device id>',
  deviceIdWithoutTempAndHum: '<your device id>',
  fourChannelsDevice: '<your device id>',
  outdatedFirmwareDevice: '<your device id>',
  updatedFirmwareDevice: '<your device id>',
};
