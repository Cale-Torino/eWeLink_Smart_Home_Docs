# Configuration

The only things you need to configure are the credentials for the API connection.
Once you use your first eWeLink node, you can set up it's eWeLink Credentials:
* E-mail address
* Password
* Region (eu, us, ...)

[Go to the nodes →](nodes.md)

[← Go back to the installation](installation.md)
